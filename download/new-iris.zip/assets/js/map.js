    function initialize() {
      var map;
      var mapOptions = {
        zoom: 14,
        center: new google.maps.LatLng(-6.185319, 106.819770),
        disableDefaultUI: true,
        zoomControl: true
      };
      map = new google.maps.Map(document.getElementById('map'),
          mapOptions);
      var markers = [
            ['Menteng IV', -6.196790, 106.828649],
            ['Dapur Cokelat', -6.193966, 106.830189],
            ['Menteng V', -6.198198, 106.827286]
        ];
      var imageHigh = 'assets/img/pin-high.png';
      var imageLow = 'assets/img/pin-low.png';

        var myLatlng = new google.maps.LatLng(-6.196790, 106.828649);
        var myLatlng2 = new google.maps.LatLng(-6.198198, 106.827286);  
        var myLatlng3 = new google.maps.LatLng(-6.180036, 106.805612);
        var myLatlng4 = new google.maps.LatLng(-6.182329, 106.802189);
        var myLatlng5 = new google.maps.LatLng(-6.193966, 106.830189);
        var myLatlng6 = new google.maps.LatLng(0.2788, 111.4753);
        var myLatlng7 = new google.maps.LatLng(-8.376028, 115.263916);
        var myLatlng8 = new google.maps.LatLng(-0.232194, 102.080323);
        var myLatlng9 = new google.maps.LatLng(-2.516541, 102.475830);
        var myLatlng10 = new google.maps.LatLng(-4.577902, 119.746338);
        var myLatlng11 = new google.maps.LatLng(3.632472, 98.552202);
        var myLatlng12 = new google.maps.LatLng(1.606127, 124.658488);
        var myLatlng13 = new google.maps.LatLng(-6.187401, 106.822763);


        var marker_2 = new google.maps.Marker({
            position: myLatlng2,
            map: map,
            icon: imageLow,
            name: 'Lokasi 2'
        });
        var marker_3 = new google.maps.Marker({
            position: myLatlng3,
            map: map,
            icon: imageLow,
            name: 'Lokasi 3'
        });
        var marker_4 = new google.maps.Marker({
            position: myLatlng4,
            map: map,
            icon: imageHigh,
            name: 'Lokasi 4'
        });
        var marker_5 = new google.maps.Marker({
            position: myLatlng5,
            map: map,
            icon: imageHigh,
            name: 'Lokasi 4'          
        });
        var marker_13 = new google.maps.Marker({
            position: myLatlng13,
            map: map,
            icon: imageHigh,
            name: 'Sarinah'          
        });        

        var aProfile = document.getElementById('profile_smartbox');
        var bProfile = document.getElementById('bprofile_smartbox');
        var aFilter = document.getElementById('filter_data');
        var bFilter = document.getElementById('filter_data2');
        var aData = document.getElementById('data_smartbox');
        var bData = document.getElementById('data_smartbox2');

        marker_13.addListener('click', function(){
            aProfile.classList.add('hide_smbox');
            bProfile.classList.add('show_smbox');
            aFilter.classList.add('hide_filter');
            bFilter.classList.add('show_filter');
            aData.classList.add('hide_data');
            bData.classList.add('show_data');
        })        

        marker_2.addListener('click', function(){
            aProfile.classList.remove('hide_smbox');
            bProfile.classList.remove('show_smbox');
            aFilter.classList.remove('hide_filter');
            bFilter.classList.remove('show_filter');
            aData.classList.remove('hide_data');
            bData.classList.remove('show_data');
        })

        marker_4.addListener('click', function(){
            aProfile.classList.add('hide_smbox');
            bProfile.classList.add('show_smbox');
            aFilter.classList.add('hide_filter');
            bFilter.classList.add('show_filter');
            aData.classList.add('hide_data');
            bData.classList.add('show_data');
        })  

        marker_5.addListener('click', function(){
            aProfile.classList.remove('hide_smbox');
            bProfile.classList.remove('show_smbox');
            aFilter.classList.remove('hide_filter');
            bFilter.classList.remove('show_filter');
            aData.classList.remove('hide_data');
            bData.classList.remove('show_data');
        })          

        marker_3.addListener('click', function(){
            aProfile.classList.add('hide_smbox');
            bProfile.classList.add('show_smbox');
            aFilter.classList.add('hide_filter');
            bFilter.classList.add('show_filter');
            aData.classList.add('hide_data');
            bData.classList.add('show_data');
        })  

    }

    google.maps.event.addDomListener(window, 'load', initialize);
