    google.load("visualization", "1", {packages:["corechart"]});
    google.setOnLoadCallback(drawCharts);
    function drawCharts() {
      
      // BEGIN BAR GRAPH
      var barData = google.visualization.arrayToDataTable([
        ['Mon', 'Users', 'Reports', 'Events'],
        ['Jan',  1050,      600,    400],
        ['Feb',  1370,      910,    600],
        ['Mar',  660,       400,    100],
        ['Apr',  1030,      540,    320],
        ['May',  1000,      480,    292],
        ['Jul',  1170,      960,    784],
        ['Jun',  660,       320,    900]
      ]);
      // set bar chart options
      var barOptions = {
        focusTarget: 'category',
        backgroundColor: 'transparent',
        colors: ['#4bbee6', '#13d797', '#f2ba60'],
        fontName: 'Open Sans',
        chartArea: {
          left: 50,
          top: 10,
          width: '100%',
          height: '40%'
        },
        bar: {
          groupWidth: '80%'
        },
        hAxis: {
          textStyle: {
            fontSize: 11
          }
        },
        vAxis: {
          minValue: 0,
          maxValue: 1500,
          baselineColor: '#DDD',
          gridlines: {
            color: '#DDD',
            count: 4
          },
          textStyle: {
            fontSize: 11
          }
        },
        legend: {
          position: 'bottom',
          textStyle: {
            fontSize: 12
          }
        },
        animation: {
          duration: 1200,
          easing: 'out',
          startup: true
        }
      };
      // draw bar chart twice so it animates
      var barChart = new google.visualization.ColumnChart(document.getElementById('bar-chart'));
      //barChart.draw(barZeroData, barOptions);
      barChart.draw(barData, barOptions);


      // // BEGIN BAR GRAPH 2
      // var barData = google.visualization.arrayToDataTable([
      //   ['Mon', 'Expanses', 'Profit', 'Sales'],
      //   ['Jan',  50,      600,    420],
      //   ['Feb',  370,      710,    400],
      //   ['Mar',  260,       100,    180],
      //   ['Apr',  630,      240,    520],
      //   ['May',  270,      480,    292],
      //   ['Jul',  570,      260,    384],
      //   ['Jun',  160,       620,    940]
      // ]);
      // // set bar chart options
      // var barOptions = {
      //   focusTarget: 'category',
      //   backgroundColor: 'transparent',
      //   colors: ['#4bbee6', '#13d797', '#f2ba60'],
      //   fontName: 'Open Sans',
      //   chartArea: {
      //     left: 50,
      //     top: 10,
      //     width: '100%',
      //     height: '70%'
      //   },
      //   bar: {
      //     groupWidth: '80%'
      //   },
      //   hAxis: {
      //     textStyle: {
      //       fontSize: 11
      //     }
      //   },
      //   vAxis: {
      //     minValue: 0,
      //     maxValue: 1500,
      //     baselineColor: '#DDD',
      //     gridlines: {
      //       color: '#DDD',
      //       count: 4
      //     },
      //     textStyle: {
      //       fontSize: 11
      //     }
      //   },
      //   legend: {
      //     position: 'bottom',
      //     textStyle: {
      //       fontSize: 12
      //     }
      //   },
      //   animation: {
      //     duration: 1200,
      //     easing: 'out',
      //     startup: true
      //   }
      // };
      // // draw bar chart twice so it animates
      // var barChart = new google.visualization.ColumnChart(document.getElementById('bar-chart-2'));
      // //barChart.draw(barZeroData, barOptions);
      // barChart.draw(barData, barOptions);


      // // BEGIN LINE GRAPH
      
      function randomNumber(base, step) {
        return Math.floor((Math.random()*step)+base);
      }
      function createData(year, start1, start2, step, offset) {
        var ar = [];
        for (var i = 0; i < 12; i++) {
          ar.push([new Date(year, i), randomNumber(start1, step)+offset, randomNumber(start2, step)+offset]);
        }
        return ar;
      }
      var randomLineData = [
        ['Year', 'All Reports', 'All Events']
      ];
      for (var x = 0; x < 7; x++) {
        var newYear = createData(2012+x, 10000, 5000, 4000, 800*Math.pow(x,2));
        for (var n = 0; n < 12; n++) {
          randomLineData.push(newYear.shift());
        }
      }
      var lineData = google.visualization.arrayToDataTable(randomLineData);

      var lineOptions = {
        backgroundColor: 'transparent',
        colors: ['#0CBCDA', '#f5be6f'],
        fontName: 'Open Sans',
        focusTarget: 'category',
        chartArea: {
          left: 50,
          top: 20,
          width: '100%',
          height: '70%'
        },
        hAxis: {
          //showTextEvery: 12,
          textStyle: {
            fontSize: 11
          },
          baselineColor: 'transparent',
          gridlines: {
            color: 'transparent'
          }
        },
        vAxis: {
          minValue: 0,
          maxValue: 50000,
          baselineColor: '#DDD',
          gridlines: {
            color: '#DDD',
            count: 4
          },
          textStyle: {
            fontSize: 11
          }
        },
        legend: {
          position: 'top',
          textStyle: {
            fontSize: 12
          }
        },
        animation: {
          duration: 1200,
          easing: 'out',
          startup: true
        }
      };

      var lineChart = new google.visualization.LineChart(document.getElementById('line-chart'));
      //lineChart.draw(zeroLineData, lineOptions);
      lineChart.draw(lineData, lineOptions);


      // BEGIN PIE CHART
      
      // pie chart data
      // var pieData = google.visualization.arrayToDataTable([
      //   ['Country', 'Page Hits'],
      //   ['Living Room',      7242],
      //   ['Bathroom',   3563],
      //   ['Lobby',   2345],
      //   ['Kitchen',    2150],
      //   ['Garage',  946]
      // ]);
      // // pie chart options
      // var pieOptions = {
      //   backgroundColor: 'transparent',
      //   pieHole: 0,
      //   colors: [ "#A6CBA4", 
      //             "#ADACAD", 
      //             "#F1B892", 
      //             "#FBE995", 
      //             "#e6516f"],
      //   pieSliceText: 'value',
      //   tooltip: {
      //     text: 'percentage'
      //   },
      //   fontName: 'Open Sans',
      //   chartArea: {
      //     width: '100%',
      //     height: '94%'
      //   },
      //   legend: {
      //     textStyle: {
      //       fontSize: 13
      //     }
      //   }
      // };
      // // draw pie chart
      // var pieChart = new google.visualization.PieChart(document.getElementById('pie-chart'));
      // pieChart.draw(pieData, pieOptions);

      // END PIE CHART


      // pie chart data
      // var pieData = google.visualization.arrayToDataTable([
      //   ['Country', 'Page Hits'],
      //   ['Garbage',      7242],
      //   ['Damage Road',   3563],
      //   ['Street Light',   2345],
      //   ['Traffic Light',    2150],
      //   ['Unspecified',  946]
      // ]);
      // // pie chart options
      // var pieOptions = {
      //   backgroundColor: 'transparent',
      //   pieHole: 0,
      //   colors: [ "#A6CBA4", 
      //             "#ADACAD", 
      //             "#F1B892", 
      //             "#FBE995", 
      //             "#e6516f"],
      //   pieSliceText: 'value',
      //   tooltip: {
      //     text: 'percentage'
      //   },
      //   fontName: 'Open Sans',
      //   chartArea: {
      //     width: '100%',
      //     height: '94%'
      //   },
      //   legend: {
      //     textStyle: {
      //       fontSize: 13
      //     }
      //   }
      // };
      // // draw pie chart
      // var pieChart = new google.visualization.PieChart(document.getElementById('pie-chart2'));
      // pieChart.draw(pieData, pieOptions);

      // END PIE CHART


      // BEGIN LINE GRAPH
      
      function randomNumber(base, step) {
        return Math.floor((Math.random()*step)+base);
      }
      function createData(year, start1, start2, step, offset) {
        var ar2 = [];
        for (var i = 0; i < 12; i++) {
          ar2.push([new Date(year, i), randomNumber(start1, step)+offset, randomNumber(start2, step)+offset]);
        }
        return ar2;
      }
      var randomLineData2 = [
        ['Year', 'Open Projects', 'Submited']
      ];
      for (var x = 0; x < 7; x++) {
        var newYear = createData(2012+x, 10000, 5000, 4000, 800*Math.pow(x,2));
        for (var n = 0; n < 12; n++) {
          randomLineData2.push(newYear.shift());
        }
      }
      var lineData2 = google.visualization.arrayToDataTable(randomLineData2);

      var lineOptions2 = {
        backgroundColor: 'transparent',
        colors: ['#1cdaae', '#f1b14a'],
        fontName: 'Open Sans',
        focusTarget: 'category',
        chartArea: {
          left: 50,
          top: 20,
          width: '100%',
          height: '70%'
        },
        hAxis: {
          //showTextEvery: 12,
          textStyle: {
            fontSize: 11
          },
          baselineColor: 'transparent',
          gridlines: {
            color: 'transparent'
          }
        },
        vAxis: {
          minValue: 0,
          maxValue: 50000,
          baselineColor: '#DDD',
          gridlines: {
            color: '#DDD',
            count: 8
          },
          textStyle: {
            fontSize: 11
          }
        },
        legend: {
          position: 'bottom',
          textStyle: {
            fontSize: 12
          }
        },
        animation: {
          duration: 1200,
          easing: 'out',
          startup: true
        }
      };

      var lineChart2 = new google.visualization.LineChart(document.getElementById('line-chart-2'));
      //lineChart.draw(zeroLineData, lineOptions);
      lineChart2.draw(lineData2, lineOptions2);


    }

    //-----------------------
    //- INSTALATION CHART 2 -
    //-----------------------

    // Get context with jQuery - using jQuery's .get() method.
    var cLine = $("#cLine2").get(0).getContext("2d");
    // This will get the first returned node in the jQuery collection.
    var cLineUnit = new Chart(cLine);

    var cLineData = {
      labels: ["Jan 16", "Feb 16", "Mar 16", "Apr 16", "Mei 16", "Jun 16", "Jul 16"],
      datasets: [
        {
          label: "Good",
          fillColor: "rgba(255, 196, 60, 0.5)",
          strokeColor: "rgb(255, 196, 60)",
          pointColor: "rgb(255, 196, 60)",
          pointStrokeColor: "rgba(255, 196, 60, 0.5)",
          pointHighlightFill: "#fff",
          pointHighlightStroke: "rgba(255, 196, 60, 0.5)",
          pointBackgroundColor: "#fff",
          data: [22, 79, 56, 61, 34, 56, 65]
        }
      ]
    };

    var cLineOptions = {
      //Boolean - If we should show the scale at all
      showScale: true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines: true,
      //String - Colour of the grid lines
      scaleGridLineColor: "rgba(0 ,0 ,0 , 0.03)",
      //Number - Width of the grid lines
      scaleGridLineWidth: 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines: true,
      //Boolean - Whether the line is curved between points
      

      scaleOverride:true,
      scaleSteps:5,
      scaleStartValue:0,
      scaleStepWidth:20,

      bezierCurve: true,
      //Number - Tension of the bezier curve between points
      bezierCurveTension: 0.3,
      //Boolean - Whether to show a dot for each point
      pointDot: true,
      //Number - Radius of each point dot in pixels
      pointDotRadius: 4,
      //Number - Pixel width of point dot stroke
      pointDotStrokeWidth: 1,
      //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
      pointHitDetectionRadius: 5,
      //Boolean - Whether to show a stroke for datasets
      datasetStroke: true,
      //Number - Pixel width of dataset stroke
      datasetStrokeWidth: 2.5,
      //Boolean - Whether to fill the dataset with a color
      datasetFill: true,
      //String - A legend template
      legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].lineColor%>\"></span><%=datasets[i].label%></li><%}%></ul>",
      //Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
      maintainAspectRatio: true,
      //Boolean - whether to make the chart responsive to window resizing
      responsive: true,
      scaleFontColor: "#ababab"
    };

    //Create the line chart
    cLineUnit.Line(cLineData, cLineOptions);

