  $(function () {
    //--------------
    //- PENJUALAN CHART -
    //--------------

    // Get context with jQuery - using jQuery's .get() method.
    var lineChartCanvas = $('#chartPengusaha').get(0).getContext('2d')
    // This will get the first returned node in the jQuery collection.
    var lineChart       = new Chart(lineChartCanvas)
    // VD3 //
    var gradientEC = lineChartCanvas.createLinearGradient(0, 0, 0, 250);
        gradientEC.addColorStop(0, 'rgba(51, 202, 255, 1)');   
        gradientEC.addColorStop(1, 'rgba(51, 202, 255, 0)');
    // 3ND VD3 //    

    var lineChartData = {
      labels  : ['January', 'February', 'March', 'April', 'May'],
      datasets: [
        {
          label               : 'Digital Goods',
          fillColor           : gradientEC,
          strokeColor         : 'rgb(84, 232, 150)',
          pointColor          : 'rgb(84, 232, 150)',
          pointStrokeColor    : 'rgb(84, 232, 150)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgb(84, 232, 150)',
          data                : [42, 68, 52, 45, 88]
        }
      ]
    }

    var lineChartOptions = {
      //Boolean - If we should show the scale at all
      showScale               : false,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines      : true,
      //String - Colour of the grid lines
      scaleGridLineColor      : 'rgba(0,0,0,.05)',
      //Number - Width of the grid lines
      scaleGridLineWidth      : 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines  : true,
      //Boolean - Whether the line is curved between points
      bezierCurve             : true,
      //Number - Tension of the bezier curve between points
      bezierCurveTension      : 0.3,
      //Boolean - Whether to show a dot for each point
      pointDot                : true,
      //Number - Radius of each point dot in pixels
      pointDotRadius          : 3,
      //Number - Pixel width of point dot stroke
      pointDotStrokeWidth     : 1,
      //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
      pointHitDetectionRadius : 20,
      //Boolean - Whether to show a stroke for datasets
      datasetStroke           : true,
      //Number - Pixel width of dataset stroke
      datasetStrokeWidth      : 2,
      //Boolean - Whether to fill the dataset with a color
      datasetFill             : false,
      //String - A legend template
      legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].lineColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
      //Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
      maintainAspectRatio     : true,
      //Boolean - whether to make the chart responsive to window resizing
      responsive              : true
    }

    //Create the line chart
    lineChart.Line(lineChartData, lineChartOptions)


    //--------------
    //- PENJUALAN CHART -
    //--------------

    // Get context with jQuery - using jQuery's .get() method.
    var lineChartCanvas = $('#chartPemasok').get(0).getContext('2d')
    // This will get the first returned node in the jQuery collection.
    var lineChart       = new Chart(lineChartCanvas)
    // VD3 //
    var gradientEC = lineChartCanvas.createLinearGradient(0, 0, 0, 250);
        gradientEC.addColorStop(0, 'rgba(51, 202, 255, 1)');   
        gradientEC.addColorStop(1, 'rgba(51, 202, 255, 0)');
    // 3ND VD3 //    

    var lineChartData = {
      labels  : ['January', 'February', 'March', 'April', 'May'],
      datasets: [
        {
          label               : 'Digital Goods',
          fillColor           : gradientEC,
          strokeColor         : 'rgb(51, 202, 255)',
          pointColor          : 'rgb(51, 202, 255)',
          pointStrokeColor    : 'rgb(51, 202, 255)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgb(51, 202, 255)',
          data                : [42, 38, 62, 55, 78]
        }
      ]
    }

    var lineChartOptions = {
      //Boolean - If we should show the scale at all
      showScale               : false,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines      : true,
      //String - Colour of the grid lines
      scaleGridLineColor      : 'rgba(0,0,0,.05)',
      //Number - Width of the grid lines
      scaleGridLineWidth      : 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines  : true,
      //Boolean - Whether the line is curved between points
      bezierCurve             : true,
      //Number - Tension of the bezier curve between points
      bezierCurveTension      : 0.3,
      //Boolean - Whether to show a dot for each point
      pointDot                : true,
      //Number - Radius of each point dot in pixels
      pointDotRadius          : 3,
      //Number - Pixel width of point dot stroke
      pointDotStrokeWidth     : 1,
      //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
      pointHitDetectionRadius : 20,
      //Boolean - Whether to show a stroke for datasets
      datasetStroke           : true,
      //Number - Pixel width of dataset stroke
      datasetStrokeWidth      : 2,
      //Boolean - Whether to fill the dataset with a color
      datasetFill             : false,
      //String - A legend template
      legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].lineColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
      //Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
      maintainAspectRatio     : true,
      //Boolean - whether to make the chart responsive to window resizing
      responsive              : true
    }

    //Create the line chart
    lineChart.Line(lineChartData, lineChartOptions)


    //--------------
    //- PRODUK CHART -
    //--------------

    // Get context with jQuery - using jQuery's .get() method.
    var lineChartCanvas = $('#chartProduk').get(0).getContext('2d')
    // This will get the first returned node in the jQuery collection.
    var lineChart       = new Chart(lineChartCanvas)

    var lineChartData = {
      labels  : ['January', 'February', 'March', 'April', 'May'],
      datasets: [
        {
          label               : 'Digital Goods',
          fillColor           : '#ff6542',
          strokeColor         : '#ff6542',
          pointColor          : '#ff6542',
          pointStrokeColor    : '#ff6542',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: '#e79c17',
          data                : [42, 68, 52, 55, 38]
        }
      ]
    }

    var lineChartOptions = {
      //Boolean - If we should show the scale at all
      showScale               : false,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines      : true,
      //String - Colour of the grid lines
      scaleGridLineColor      : 'rgba(0,0,0,.05)',
      //Number - Width of the grid lines
      scaleGridLineWidth      : 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines  : true,
      //Boolean - Whether the line is curved between points
      bezierCurve             : true,
      //Number - Tension of the bezier curve between points
      bezierCurveTension      : 0.3,
      //Boolean - Whether to show a dot for each point
      pointDot                : true,
      //Number - Radius of each point dot in pixels
      pointDotRadius          : 3,
      //Number - Pixel width of point dot stroke
      pointDotStrokeWidth     : 1,
      //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
      pointHitDetectionRadius : 20,
      //Boolean - Whether to show a stroke for datasets
      datasetStroke           : true,
      //Number - Pixel width of dataset stroke
      datasetStrokeWidth      : 2,
      //Boolean - Whether to fill the dataset with a color
      datasetFill             : false,
      //String - A legend template
      legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].lineColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
      //Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
      maintainAspectRatio     : true,
      //Boolean - whether to make the chart responsive to window resizing
      responsive              : true
    }

    //Create the line chart
    lineChart.Line(lineChartData, lineChartOptions)


    //--------------
    //- PRODUK MASUK KELUAR CHART -
    //--------------

    // Get context with jQuery - using jQuery's .get() method.
    var lineChartCanvas = $('#chartInOut').get(0).getContext('2d')
    // This will get the first returned node in the jQuery collection.
    var lineChart       = new Chart(lineChartCanvas)

    var lineChartData = {
      labels  : ['January', 'February', 'March', 'April', 'May'],
      datasets: [
        {
          label               : 'Barang Masuk',
          fillColor           : 'rgba(3, 170, 228, 0.6)',
          strokeColor         : 'rgba(3, 170, 228, 1)',
          pointColor          : 'rgba(3, 170, 228, 1)',
          pointStrokeColor    : 'rgba(3, 170, 228, 1)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(3, 170, 228, 1)',
          data                : [42, 68, 52, 55, 38]
        },
        {
          label               : 'Barang Keluar',
          fillColor           : 'rgb(23, 231, 230, 0.5)',
          strokeColor         : 'rgb(23, 231, 230)',
          pointColor          : 'rgb(23, 231, 230)',
          pointStrokeColor    : 'rgb(23, 231, 230)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgb(23, 231, 230)',
          data                : [32, 38, 72, 65, 88]
        }
      ]
    }

    var lineChartOptions = {
      //Boolean - If we should show the scale at all
      showScale               : true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines      : true,
      //String - Colour of the grid lines
      scaleGridLineColor      : 'rgba(0,0,0,.05)',
      //Number - Width of the grid lines
      scaleGridLineWidth      : 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines  : true,
      //Boolean - Whether the line is curved between points
      bezierCurve             : true,
      //Number - Tension of the bezier curve between points
      bezierCurveTension      : 0.3,
      //Boolean - Whether to show a dot for each point
      pointDot                : false,
      //Number - Radius of each point dot in pixels
      pointDotRadius          : 3,
      //Number - Pixel width of point dot stroke
      pointDotStrokeWidth     : 1,
      //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
      pointHitDetectionRadius : 20,
      //Boolean - Whether to show a stroke for datasets
      datasetStroke           : true,
      //Number - Pixel width of dataset stroke
      datasetStrokeWidth      : 2,
      //Boolean - Whether to fill the dataset with a color
      datasetFill             : true,
      //String - A legend template
      legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].lineColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
      //Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
      maintainAspectRatio     : true,
      //Boolean - whether to make the chart responsive to window resizing
      responsive              : true
    }

    //Create the line chart
    lineChart.Line(lineChartData, lineChartOptions)


  // -------------
  // - PIE CHART -
  // -------------
  // Get context with jQuery - using jQuery's .get() method.
  var pieChartCanvas = $('#chartPengguna').get(0).getContext('2d');
  var pieChart       = new Chart(pieChartCanvas);
  var PieData        = [
    {
      value    : 700,
      color    : '#17B1E7',
      highlight: '#17B1E7',
      label    : 'Pengusaha'
    },
    {
      value    : 500,
      color    : '#0D80FE',
      highlight: '#0D80FE',
      label    : 'Toko'
    },
    {
      value    : 400,
      color    : '#0CF4B1',
      highlight: '#0CF4B1',
      label    : 'Admin Kasir'
    }
  ];
  var pieOptions     = {
    // Boolean - Whether we should show a stroke on each segment
    segmentShowStroke    : true,
    // String - The colour of each segment stroke
    segmentStrokeColor   : '#fff',
    // Number - The width of each segment stroke
    segmentStrokeWidth   : 1,
    // Number - The percentage of the chart that we cut out of the middle
    percentageInnerCutout: 0, // This is 0 for Pie charts
    // Number - Amount of animation steps
    animationSteps       : 100,
    // String - Animation easing effect
    animationEasing      : 'easeOutBounce',
    // Boolean - Whether we animate the rotation of the Doughnut
    animateRotate        : true,
    // Boolean - Whether we animate scaling the Doughnut from the centre
    animateScale         : false,
    // Boolean - whether to make the chart responsive to window resizing
    responsive           : true,
    // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
    maintainAspectRatio  : false,
    // String - A legend template
    legendTemplate       : '<ul class=\'<%=name.toLowerCase()%>-legend\'><% for (var i=0; i<segments.length; i++){%><li><span style=\'background-color:<%=segments[i].fillColor%>\'></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>',
    // String - A tooltip template
    tooltipTemplate      : '<%=value %> <%=label%>'
  };
  // Create pie or douhnut chart
  // You can switch between pie and douhnut using the method below.
  pieChart.Doughnut(PieData, pieOptions);
  // -----------------
  // - END PIE CHART -
  // -----------------


    //-------------
    //- BAR CHART REPORT -
    //-------------
    var barChartCanvas                   = $('#chartProfitLoss').get(0).getContext('2d')
    var barChart                         = new Chart(barChartCanvas)
    var barChartData = {
      labels  : ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
      datasets: [
        {
          label               : 'Profit',
          fillColor           : 'rgb(51, 202, 255)',
          strokeColor         : 'rgb(51, 202, 255)',
          pointColor          : 'rgb(51, 202, 255)',
          pointStrokeColor    : 'rgb(51, 202, 255)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgb(51, 202, 255)',
          data                : [65, 59, 80, 81, 56, 55, 40]
        },
        {
          label               : 'Loss',
          fillColor           : '#54e896',
          strokeColor         : '#54e896',
          pointColor          : '#54e896',
          pointStrokeColor    : '#54e896',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: '#54e896',
          data                : [28, 48, 40, 19, 86, 27, 90]
        }
      ]
    }
    var barChartOptions                  = {
      //Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
      scaleBeginAtZero        : true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines      : true,
      //String - Colour of the grid lines
      scaleGridLineColor      : 'rgba(0,0,0,.05)',
      //Number - Width of the grid lines
      scaleGridLineWidth      : 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines  : true,
      //Boolean - If there is a stroke on each bar
      barShowStroke           : true,
      //Number - Pixel width of the bar stroke
      barStrokeWidth          : 1,
      //Number - Spacing between each of the X value sets
      barValueSpacing         : 40,
      //Number - Spacing between data sets within X values
      barDatasetSpacing       : 4,
      //String - A legend template
      legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].fillColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
      //Boolean - whether to make the chart responsive
      responsive              : true,
      maintainAspectRatio     : true
    }

    barChart.Bar(barChartData, barChartOptions)


});